<link rel="stylesheet" type="text/css" href="css/styles.css">

<p class='footer'>
	&copy 2023 All rights reserved.
</p>
