<?php session_start();?>
<!DOCTYPE html>
<html>
<head>
    <title>Online Book Store</title>
</head>
<body>
    <?php
        include_once "header.php";
        include_once "slider.php";
        include_once "footer.php";
    ?>
</body>
</html>
